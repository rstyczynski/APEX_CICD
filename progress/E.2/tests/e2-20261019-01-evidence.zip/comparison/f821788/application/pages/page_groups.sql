prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 821788
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3077323948406566
,p_default_application_id=>821788
,p_default_id_offset=>0
,p_default_owner=>'E2_0254C95F_A'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3288720819415010)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
