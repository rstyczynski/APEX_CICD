prompt --application/shared_components/user_interface/lovs/e2_greeting_words
begin
--   Manifest
--     E2 GREETING WORDS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3077323948406566
,p_default_application_id=>821788
,p_default_id_offset=>0
,p_default_owner=>'E2_0254C95F_A'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3677757465437351)
,p_lov_name=>'E2 GREETING WORDS'
,p_lov_query=>'select setting_value d, setting_key r from e2_settings where setting_key in (''HELLO'',''WORLD'')'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>2209919
);
wwv_flow_imp.component_end;
end;
/
