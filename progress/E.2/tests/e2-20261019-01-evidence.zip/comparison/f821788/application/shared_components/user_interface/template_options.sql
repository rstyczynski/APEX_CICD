prompt --application/shared_components/user_interface/template_options
begin
--   Manifest
--     THEME OPTIONS: 821788
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3077323948406566
,p_default_application_id=>821788
,p_default_id_offset=>0
,p_default_owner=>'E2_0254C95F_A'
);
null;
wwv_flow_imp.component_end;
end;
/
