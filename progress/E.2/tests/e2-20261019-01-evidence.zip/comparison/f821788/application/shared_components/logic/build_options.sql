prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 821788
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>3077323948406566
,p_default_application_id=>821788
,p_default_id_offset=>0
,p_default_owner=>'E2_0254C95F_A'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(3282617100414977)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>2202531
);
wwv_flow_imp.component_end;
end;
/
