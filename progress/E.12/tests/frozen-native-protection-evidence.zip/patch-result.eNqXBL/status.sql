set serveroutput on
begin E1_CTRL.e1_release.show_status; end;
/
