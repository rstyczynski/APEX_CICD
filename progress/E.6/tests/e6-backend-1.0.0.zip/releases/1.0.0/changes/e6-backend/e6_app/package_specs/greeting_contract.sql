-- liquibase formatted sql
-- changeset E6_APP:1795629915367 stripComments:false  logicalFilePath:e6-backend/e6_app/package_specs/greeting_contract.sql
-- sqlcl_snapshot src/database/e6_app/package_specs/greeting_contract.sql:null:4cc5ca0a0a3f616f8904e655560fe7b09a43c3e3:create

create or replace package e6_app.greeting_contract authid definer as
    function render (
        p_text   varchar2,
        p_suffix varchar2 default null
    ) return varchar2;
 -- Deprecated in 1.1; callable for all 1.x consumers, removal requires 2.0.
    function hello (
        p_name varchar2
    ) return varchar2;

    function render_v2 (
        p_text varchar2
    ) return varchar2;

end;
/

