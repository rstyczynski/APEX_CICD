-- liquibase formatted sql
-- changeset E6_APP:1795629915482 stripComments:false  logicalFilePath:e6-backend/e6_app/tables/greeting_audit.sql
-- sqlcl_snapshot src/database/e6_app/tables/greeting_audit.sql:null:cf8048383e559705f98c9fd9a69d9f6bcc2857e8:create

create table e6_app.greeting_audit (
    country_code varchar2(2 byte) not null enable,
    request_key  varchar2(80 byte) not null enable,
    actor        varchar2(255 byte) not null enable
);

alter table e6_app.greeting_audit
    add primary key ( country_code,
                      request_key )
        using index enable;

