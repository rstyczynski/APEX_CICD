-- liquibase formatted sql
-- changeset E6_APP:1795629915430 stripComments:false  logicalFilePath:e6-backend/e6_app/tables/country_permissions.sql
-- sqlcl_snapshot src/database/e6_app/tables/country_permissions.sql:null:16305295aaa7f283c9a7ecf166ba5a8e6fdf1365:create

create table e6_app.country_permissions (
    user_name    varchar2(255 byte) not null enable,
    country_code varchar2(2 byte) not null enable,
    enabled      char(1 byte) default 'Y' not null enable
);

alter table e6_app.country_permissions
    add
        check ( country_code in ( 'PL', 'DE' ) ) enable;

alter table e6_app.country_permissions
    add
        check ( enabled in ( 'Y', 'N' ) ) enable;

alter table e6_app.country_permissions
    add primary key ( user_name,
                      country_code )
        using index enable;

