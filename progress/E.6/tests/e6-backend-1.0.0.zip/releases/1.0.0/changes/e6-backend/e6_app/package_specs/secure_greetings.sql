-- liquibase formatted sql
-- changeset E6_APP:1795629915379 stripComments:false  logicalFilePath:e6-backend/e6_app/package_specs/secure_greetings.sql
-- sqlcl_snapshot src/database/e6_app/package_specs/secure_greetings.sql:null:a859ba2c22e4f496e645753a6546ce5fe7225d3d:create

create or replace package e6_app.secure_greetings authid definer as
    procedure submit_request (
        p_key     varchar2,
        p_country varchar2,
        p_text    varchar2
    );

end;
/

