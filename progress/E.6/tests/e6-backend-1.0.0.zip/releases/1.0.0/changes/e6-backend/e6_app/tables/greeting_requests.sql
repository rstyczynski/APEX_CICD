-- liquibase formatted sql
-- changeset E6_APP:1795629915518 stripComments:false  logicalFilePath:e6-backend/e6_app/tables/greeting_requests.sql
-- sqlcl_snapshot src/database/e6_app/tables/greeting_requests.sql:null:ad02a18aa54d73d9ffb957e616232b79b3a6d321:create

create table e6_app.greeting_requests (
    country_code  varchar2(2 byte) not null enable,
    request_key   varchar2(80 byte) not null enable,
    greeting_text varchar2(200 byte) not null enable,
    actor         varchar2(255 byte) not null enable
);

alter table e6_app.greeting_requests
    add primary key ( country_code,
                      request_key )
        using index enable;

