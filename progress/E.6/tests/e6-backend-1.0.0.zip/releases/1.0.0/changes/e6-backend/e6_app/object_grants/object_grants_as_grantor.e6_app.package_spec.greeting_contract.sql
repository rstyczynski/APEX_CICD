-- liquibase formatted sql
-- changeset E6_APP:1795629915240 stripComments:false  logicalFilePath:e6-backend/e6_app/object_grants/object_grants_as_grantor.e6_app.package_spec.greeting_contract.sql
-- sqlcl_snapshot src/database/e6_app/object_grants/object_grants_as_grantor.e6_app.package_spec.greeting_contract.sql:null:f6c421df5776637b8a775b950f20aeeb559eeb0d:create

grant execute on e6_app.greeting_contract to e6_test;

