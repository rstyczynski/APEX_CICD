-- liquibase formatted sql
-- changeset E6_APP:1795629915402 stripComments:false  logicalFilePath:e6-backend/e6_app/ref_constraints/greeting_audit.e6_app.greeting_requests.sql
-- sqlcl_snapshot src/database/e6_app/ref_constraints/greeting_audit.e6_app.greeting_requests.sql:null:b2e3f748b7195eeb2aafd3423614f9177a3cbaa9:create

alter table e6_app.greeting_audit
    add
        foreign key ( country_code,
                      request_key )
            references e6_app.greeting_requests ( country_code,
                                                  request_key )
        enable;

