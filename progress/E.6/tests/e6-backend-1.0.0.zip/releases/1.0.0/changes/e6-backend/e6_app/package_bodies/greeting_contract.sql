-- liquibase formatted sql
-- changeset E6_APP:1795629915309 stripComments:false  logicalFilePath:e6-backend/e6_app/package_bodies/greeting_contract.sql
-- sqlcl_snapshot src/database/e6_app/package_bodies/greeting_contract.sql:null:e9376091fd9635882bd3593788bb405a790fc5b3:create

create or replace package body e6_app.greeting_contract as

    function render (
        p_text   varchar2,
        p_suffix varchar2 default null
    ) return varchar2 is
    begin
        if trim(p_text) is null
           or length(trim(p_text)) > 100 then
            raise_application_error(-20410, 'Greeting text must contain 1 to 100 characters.');
        end if;

        return 'Hello '
               || trim(p_text)
               || p_suffix;
    end;

    function hello (
        p_name varchar2
    ) return varchar2 is
    begin
        return render(p_text => p_name);
    end;

    function render_v2 (
        p_text varchar2
    ) return varchar2 is
    begin
        return
            json_object(
                'message' value render(p_text)
            returning varchar2);
    end;

end;
/

