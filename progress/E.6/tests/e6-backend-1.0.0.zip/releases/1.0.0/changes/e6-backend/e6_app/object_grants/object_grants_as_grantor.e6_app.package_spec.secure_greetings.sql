-- liquibase formatted sql
-- changeset E6_APP:1795629915275 stripComments:false  logicalFilePath:e6-backend/e6_app/object_grants/object_grants_as_grantor.e6_app.package_spec.secure_greetings.sql
-- sqlcl_snapshot src/database/e6_app/object_grants/object_grants_as_grantor.e6_app.package_spec.secure_greetings.sql:null:6243579db04fde5d4c5d2e7a2e5d240259846d48:create

grant execute on e6_app.secure_greetings to e6_test;

