create table e7r_55d00b.greetings(id number primary key, message varchar2(100) not null);
create table e7r_55d00b.release_reference(code varchar2(20) primary key, value varchar2(40));
insert into e7r_55d00b.release_reference values('LANGUAGE','en');
create table e7r_55d00b.migrations(version varchar2(20) primary key);
insert into e7r_55d00b.migrations values('1.0.0');
create or replace package e7r_55d00b.greeting_api as function render(p_text varchar2) return varchar2; end;
/
create or replace package body e7r_55d00b.greeting_api as function render(p_text varchar2) return varchar2 is begin return 'Hello '||trim(p_text); end; end;
/
grant execute on e7r_55d00b.greeting_api to e7c_55d00b;
commit;
