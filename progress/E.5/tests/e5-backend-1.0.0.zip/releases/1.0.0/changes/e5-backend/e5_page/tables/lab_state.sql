-- liquibase formatted sql
-- changeset E5_PAGE:1795628016690 stripComments:false  logicalFilePath:e5-backend/e5_page/tables/lab_state.sql
-- sqlcl_snapshot src/database/e5_page/tables/lab_state.sql:null:517180f9f6b119177ebc3ddc4774cece752d2f87:create

create table e5_page.lab_state (
    state_key  varchar2(30 byte),
    parent_key varchar2(30 byte),
    state      varchar2(20 byte),
    reason     varchar2(1000 byte)
);

alter table e5_page.lab_state
    add
        check ( state in ( 'ready', 'maintenance', 'failed' ) ) enable;

alter table e5_page.lab_state add primary key ( state_key )
    using index enable;

