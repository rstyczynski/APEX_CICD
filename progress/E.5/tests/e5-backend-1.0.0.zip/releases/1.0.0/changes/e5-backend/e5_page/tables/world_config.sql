-- liquibase formatted sql
-- changeset E5_PAGE:1795628016751 stripComments:false  logicalFilePath:e5-backend/e5_page/tables/world_config.sql
-- sqlcl_snapshot src/database/e5_page/tables/world_config.sql:null:8cd36a3c2d9f884f356f1ca26aefee88cc8d11d6:create

create table e5_page.world_config (
    config_id        number,
    prefix           varchar2(30 char),
    default_entry_id number
);

alter table e5_page.world_config add check ( config_id = 1 ) enable;

alter table e5_page.world_config add primary key ( config_id )
    using index enable;

