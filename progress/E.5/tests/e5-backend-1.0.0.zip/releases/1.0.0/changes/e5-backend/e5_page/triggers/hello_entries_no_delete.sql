-- liquibase formatted sql
-- changeset E5_PAGE:1795628017014 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/hello_entries_no_delete.sql
-- sqlcl_snapshot src/database/e5_page/triggers/hello_entries_no_delete.sql:null:f19c05e817a7ce706dffbe15d05e06f24341aefe:create

create or replace editionable trigger e5_page.hello_entries_no_delete before
    delete on e5_page.hello_entries
begin
    raise_application_error(-20311, 'Deactivate Hello entries instead of deleting');
end;
/

alter trigger e5_page.hello_entries_no_delete enable;

