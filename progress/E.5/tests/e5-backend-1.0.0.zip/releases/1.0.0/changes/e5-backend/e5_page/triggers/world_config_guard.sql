-- liquibase formatted sql
-- changeset E5_PAGE:1795628017048 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/world_config_guard.sql
-- sqlcl_snapshot src/database/e5_page/triggers/world_config_guard.sql:null:f639b5f41f55f4f37b9990953dce8a5696e2033e:create

create or replace editionable trigger e5_page.world_config_guard before
    insert or update on e5_page.world_config
    for each row
declare
    n number;
begin
    lab_runtime.assert_ready;
    select
        count(*)
    into n
    from
        world_entries
    where
            entry_id = :new.default_entry_id
        and active = 'Y';

    if n <> 1 then
        raise_application_error(-20322, 'World default must be an active World entry');
    end if;
end;
/

alter trigger e5_page.world_config_guard enable;

