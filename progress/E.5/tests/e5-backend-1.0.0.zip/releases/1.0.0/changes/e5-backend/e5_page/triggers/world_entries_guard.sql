-- liquibase formatted sql
-- changeset E5_PAGE:1795628017116 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/world_entries_guard.sql
-- sqlcl_snapshot src/database/e5_page/triggers/world_entries_guard.sql:null:a343d2c445b60e4111cafcb87ca94963cca52301:create

create or replace editionable trigger e5_page.world_entries_guard before
    insert or update on e5_page.world_entries
    for each row
declare
    n number;
begin
    lab_runtime.assert_ready;
    :new.entry_text := trim(:new.entry_text);
    if :new.active = 'N' then
        select
            count(*)
        into n
        from
            world_config
        where
            default_entry_id = :new.entry_id;

        if n > 0 then
            raise_application_error(-20320, 'Choose another active World default before deactivation');
        end if;
    end if;

end;
/

alter trigger e5_page.world_entries_guard enable;

