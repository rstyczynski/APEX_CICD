-- liquibase formatted sql
-- changeset E5_PAGE:1795628017150 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/world_entries_no_delete.sql
-- sqlcl_snapshot src/database/e5_page/triggers/world_entries_no_delete.sql:null:46b170c99159f392ea43d9c6f4918e00ccd8d209:create

create or replace editionable trigger e5_page.world_entries_no_delete before
    delete on e5_page.world_entries
begin
    raise_application_error(-20321, 'Deactivate World entries instead of deleting');
end;
/

alter trigger e5_page.world_entries_no_delete enable;

