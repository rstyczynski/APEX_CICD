-- liquibase formatted sql
-- changeset E5_PAGE:1795628016487 stripComments:false  logicalFilePath:e5-backend/e5_page/tables/greeting_history.sql
-- sqlcl_snapshot src/database/e5_page/tables/greeting_history.sql:null:552bde1321c99d16d051f6f2335e70be2ccaf5cd:create

create table e5_page.greeting_history (
    greeting_id    number generated always as identity not null enable,
    hello_entry_id number not null enable,
    world_entry_id number not null enable,
    hello_text     varchar2(100 char) not null enable,
    world_text     varchar2(100 char) not null enable,
    hello_prefix   varchar2(30 char),
    world_prefix   varchar2(30 char),
    greeting_text  varchar2(261 char) not null enable,
    created_at     timestamp(6) with time zone default systimestamp not null enable,
    actor          varchar2(255 char) not null enable
);

alter table e5_page.greeting_history add primary key ( greeting_id )
    using index enable;

