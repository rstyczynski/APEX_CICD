-- liquibase formatted sql
-- changeset E5_PAGE:1795628016878 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/greeting_history_insert_guard.sql
-- sqlcl_snapshot src/database/e5_page/triggers/greeting_history_insert_guard.sql:null:cbea8c2cc3c3c64f50a24d4b756cd066b9ce375b:create

create or replace editionable trigger e5_page.greeting_history_insert_guard before
    insert on e5_page.greeting_history
begin
    lab_runtime.assert_ready;
end;
/

alter trigger e5_page.greeting_history_insert_guard enable;

