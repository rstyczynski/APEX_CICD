-- liquibase formatted sql
-- changeset E5_PAGE:1795628016946 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/hello_config_no_delete.sql
-- sqlcl_snapshot src/database/e5_page/triggers/hello_config_no_delete.sql:null:cc727e445196f87254cec824e4bee7bb287e4cd8:create

create or replace editionable trigger e5_page.hello_config_no_delete before
    delete on e5_page.hello_config
begin
    raise_application_error(-20313, 'Hello configuration cannot be deleted');
end;
/

alter trigger e5_page.hello_config_no_delete enable;

