-- liquibase formatted sql
-- changeset E5_PAGE:1795628016847 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/greeting_history_immutable.sql
-- sqlcl_snapshot src/database/e5_page/triggers/greeting_history_immutable.sql:null:e47c382368fc2560ec67b4adb5b0b5d97aa7524e:create

create or replace editionable trigger e5_page.greeting_history_immutable before
    update or delete on e5_page.greeting_history
begin
    raise_application_error(-20305, 'Greeting history is immutable');
end;
/

alter trigger e5_page.greeting_history_immutable enable;

