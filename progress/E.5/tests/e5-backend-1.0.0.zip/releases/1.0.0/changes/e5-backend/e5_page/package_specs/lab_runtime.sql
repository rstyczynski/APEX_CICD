-- liquibase formatted sql
-- changeset E5_PAGE:1795628016383 stripComments:false  logicalFilePath:e5-backend/e5_page/package_specs/lab_runtime.sql
-- sqlcl_snapshot src/database/e5_page/package_specs/lab_runtime.sql:null:b1146770145eceaeefcba6b1f411b668652bd976:create

create or replace package e5_page.lab_runtime authid definer as
    procedure assert_ready;

    function record_greeting (
        p_hello_id number default null,
        p_world_id number default null
    ) return varchar2;

end;
/

