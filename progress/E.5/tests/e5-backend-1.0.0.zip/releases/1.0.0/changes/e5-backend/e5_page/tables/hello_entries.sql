-- liquibase formatted sql
-- changeset E5_PAGE:1795628016568 stripComments:false  logicalFilePath:e5-backend/e5_page/tables/hello_entries.sql
-- sqlcl_snapshot src/database/e5_page/tables/hello_entries.sql:null:a47d13d190032f2612ca3020489611bc3eb58fa2:create

create table e5_page.hello_entries (
    entry_id   number generated always as identity not null enable,
    entry_text varchar2(100 char) not null enable,
    active     char(1 byte) default 'Y' not null enable
);

alter table e5_page.hello_entries
    add
        check ( active in ( 'Y', 'N' ) ) enable;

alter table e5_page.hello_entries
    add constraint hello_text_nonblank check ( regexp_like ( entry_text,
                                                             '[^[:space:]]' ) ) enable;

alter table e5_page.hello_entries
    add constraint hello_text_valid
        check ( length(trim(entry_text)) between 1 and 100 ) enable;

alter table e5_page.hello_entries add primary key ( entry_id )
    using index enable;

