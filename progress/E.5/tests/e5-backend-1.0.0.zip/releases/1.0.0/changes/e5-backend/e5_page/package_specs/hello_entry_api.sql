-- liquibase formatted sql
-- changeset E5_PAGE:1795628016366 stripComments:false  logicalFilePath:e5-backend/e5_page/package_specs/hello_entry_api.sql
-- sqlcl_snapshot src/database/e5_page/package_specs/hello_entry_api.sql:null:dde8d07be434c3f2c01e2b029000bdb8887c9fd6:create

create or replace package e5_page.hello_entry_api authid definer as
    function validation_error (
        p_text varchar2
    ) return varchar2;

    procedure create_entry (
        p_text   varchar2,
        p_active varchar2 default 'Y',
        p_id     out number
    );

end hello_entry_api;
/

