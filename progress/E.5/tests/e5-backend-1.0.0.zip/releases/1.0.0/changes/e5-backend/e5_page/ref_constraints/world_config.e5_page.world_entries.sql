-- liquibase formatted sql
-- changeset E5_PAGE:1795628016453 stripComments:false  logicalFilePath:e5-backend/e5_page/ref_constraints/world_config.e5_page.world_entries.sql
-- sqlcl_snapshot src/database/e5_page/ref_constraints/world_config.e5_page.world_entries.sql:null:ae90ab0f422ab267eab3382a0d60066bca00c743:create

alter table e5_page.world_config
    add
        foreign key ( default_entry_id )
            references e5_page.world_entries ( entry_id )
        enable;

