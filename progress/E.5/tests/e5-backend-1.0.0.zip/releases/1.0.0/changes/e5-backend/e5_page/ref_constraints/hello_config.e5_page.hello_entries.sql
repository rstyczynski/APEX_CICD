-- liquibase formatted sql
-- changeset E5_PAGE:1795628016425 stripComments:false  logicalFilePath:e5-backend/e5_page/ref_constraints/hello_config.e5_page.hello_entries.sql
-- sqlcl_snapshot src/database/e5_page/ref_constraints/hello_config.e5_page.hello_entries.sql:null:4823e3db4983a479c6c929cb281efad1904ef66f:create

alter table e5_page.hello_config
    add
        foreign key ( default_entry_id )
            references e5_page.hello_entries ( entry_id )
        enable;

