-- liquibase formatted sql
-- changeset E5_PAGE:1795628016797 stripComments:false  logicalFilePath:e5-backend/e5_page/tables/world_entries.sql
-- sqlcl_snapshot src/database/e5_page/tables/world_entries.sql:null:c53f6506260c63348c49820719a214d5e1bb9ad2:create

create table e5_page.world_entries (
    entry_id   number generated always as identity not null enable,
    entry_text varchar2(100 char) not null enable,
    active     char(1 byte) default 'Y' not null enable
);

alter table e5_page.world_entries
    add
        check ( active in ( 'Y', 'N' ) ) enable;

alter table e5_page.world_entries
    add constraint world_text_valid
        check ( length(trim(entry_text)) between 1 and 100 ) enable;

alter table e5_page.world_entries add primary key ( entry_id )
    using index enable;

