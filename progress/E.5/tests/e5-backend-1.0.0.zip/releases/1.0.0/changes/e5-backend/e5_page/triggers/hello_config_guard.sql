-- liquibase formatted sql
-- changeset E5_PAGE:1795628016913 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/hello_config_guard.sql
-- sqlcl_snapshot src/database/e5_page/triggers/hello_config_guard.sql:null:8185430ef3800191f1f37dbeb653eba4f573dce0:create

create or replace editionable trigger e5_page.hello_config_guard before
    insert or update on e5_page.hello_config
    for each row
declare
    n number;
begin
    lab_runtime.assert_ready;
    select
        count(*)
    into n
    from
        hello_entries
    where
            entry_id = :new.default_entry_id
        and active = 'Y';

    if n <> 1 then
        raise_application_error(-20312, 'Hello default must be an active Hello entry');
    end if;
end;
/

alter trigger e5_page.hello_config_guard enable;

