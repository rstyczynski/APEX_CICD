-- liquibase formatted sql
-- changeset E5_PAGE:1795628016982 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/hello_entries_guard.sql
-- sqlcl_snapshot src/database/e5_page/triggers/hello_entries_guard.sql:null:ac5361a9ac5bebc64bf1c737c747917890845a98:create

create or replace editionable trigger e5_page.hello_entries_guard before
    insert or update on e5_page.hello_entries
    for each row
declare
    n number;
begin
    lab_runtime.assert_ready;
    :new.entry_text := regexp_replace(:new.entry_text,
                                      '^[[:space:]]+|[[:space:]]+$',
                                      '');
    if :new.entry_text is null then
        raise_application_error(-20314, 'Hello entry must contain non-whitespace text');
    end if;

    if :new.active = 'N' then
        select
            count(*)
        into n
        from
            hello_config
        where
            default_entry_id = :new.entry_id;

        if n > 0 then
            raise_application_error(-20310, 'Choose another active Hello default before deactivation');
        end if;
    end if;

end;
/

alter trigger e5_page.hello_entries_guard enable;

