-- liquibase formatted sql
-- changeset E5_PAGE:1795628017080 stripComments:false  logicalFilePath:e5-backend/e5_page/triggers/world_config_no_delete.sql
-- sqlcl_snapshot src/database/e5_page/triggers/world_config_no_delete.sql:null:02391bf7eba63c2f902b7bb747d24f508ba87e5a:create

create or replace editionable trigger e5_page.world_config_no_delete before
    delete on e5_page.world_config
begin
    raise_application_error(-20323, 'World configuration cannot be deleted');
end;
/

alter trigger e5_page.world_config_no_delete enable;

