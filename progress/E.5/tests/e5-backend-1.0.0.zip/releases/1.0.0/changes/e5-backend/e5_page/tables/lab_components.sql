-- liquibase formatted sql
-- changeset E5_PAGE:1795628016634 stripComments:false  logicalFilePath:e5-backend/e5_page/tables/lab_components.sql
-- sqlcl_snapshot src/database/e5_page/tables/lab_components.sql:null:50d86afd9e10223ef0835885293b23adeac86629:create

create table e5_page.lab_components (
    component varchar2(20 byte),
    installed number(1, 0) not null enable,
    version   varchar2(30 byte)
);

alter table e5_page.lab_components
    add
        check ( installed in ( 0, 1 ) ) enable;

alter table e5_page.lab_components
    add constraint lab_component_presence
        check ( ( installed = 0
                  and version is null )
                or ( installed = 1
                     and version is not null ) ) enable;

alter table e5_page.lab_components add primary key ( component )
    using index enable;

