-- liquibase formatted sql
-- changeset E5_PAGE:1795628016523 stripComments:false  logicalFilePath:e5-backend/e5_page/tables/hello_config.sql
-- sqlcl_snapshot src/database/e5_page/tables/hello_config.sql:null:9a238ee8d4c03c0c8c0cd4fe7989921e452035cd:create

create table e5_page.hello_config (
    config_id        number,
    prefix           varchar2(30 char),
    default_entry_id number
);

alter table e5_page.hello_config add check ( config_id = 1 ) enable;

alter table e5_page.hello_config add primary key ( config_id )
    using index enable;

