-- liquibase formatted sql
-- changeset AUTHOR16:1795706314892 stripComments:false  logicalFilePath:release/author16/tables/preserved.sql
-- sqlcl_snapshot src/database/author16/tables/preserved.sql:null:4097f08ad30bd07bba217dfe42b3ea1922327de9:create

create table author16.preserved (
    id      number,
    message varchar2(80 byte)
);

alter table author16.preserved add primary key ( id )
    using index enable;

