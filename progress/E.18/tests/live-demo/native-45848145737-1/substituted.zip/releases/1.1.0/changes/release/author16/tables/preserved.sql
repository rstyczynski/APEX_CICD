-- liquibase formatted sql
-- changeset AUTHOR16:1795707128614 stripComments:false  logicalFilePath:release/author16/tables/preserved.sql
-- sqlcl_snapshot src/database/author16/tables/preserved.sql:3ca9aaf2940e616c7c5792583c9897208c39f244:3eb7dac98f17601fdcf86bc010e4023d0885fac8:alter

alter table author16.preserved add (
    extra varchar2(80)
)
/

